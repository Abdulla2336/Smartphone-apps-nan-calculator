package com.example.moviepicker

import android.graphics.Typeface
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val selectedGenres = mutableSetOf<String>()
    private lateinit var txtResult: TextView

    private val movieSuggestions = mapOf(
        setOf("Action", "Comedy") to listOf("Rush Hour", "Deadpool", "21 Jump Street"),
        setOf("Action", "Drama") to listOf("Gladiator", "The Dark Knight", "Braveheart"),
        setOf("Action", "Romance") to listOf("Mr. & Mrs. Smith", "The Terminator", "True Lies"),
        setOf("Action", "Sci-Fi") to listOf("Inception", "The Matrix", "Edge of Tomorrow"),
        setOf("Action", "Horror") to listOf("World War Z", "Underworld", "I Am Legend"),
        setOf("Action", "Mystery") to listOf("Tenet", "Looper", "Minority Report"),
        setOf("Action", "Fantasy") to listOf("Thor: Ragnarok", "Doctor Strange", "Wonder Woman"),
        setOf("Action", "Animation") to listOf("The Incredibles", "Big Hero 6", "Spider-Man: Into the Spider-Verse"),
        setOf("Action", "Thriller") to listOf("John Wick", "Taken", "Mad Max: Fury Road"),

        setOf("Comedy", "Drama") to listOf("The Truman Show", "Little Miss Sunshine", "The Pursuit of Happyness"),
        setOf("Comedy", "Romance") to listOf("Crazy Rich Asians", "10 Things I Hate About You", "The Proposal"),
        setOf("Comedy", "Sci-Fi") to listOf("Men in Black", "Galaxy Quest", "Ghostbusters"),
        setOf("Comedy", "Horror") to listOf("Shaun of the Dead", "Zombieland", "Scary Movie"),
        setOf("Comedy", "Mystery") to listOf("Knives Out", "Game Night", "Clue"),
        setOf("Comedy", "Fantasy") to listOf("Bruce Almighty", "Click", "The Mask"),
        setOf("Comedy", "Animation") to listOf("Shrek", "The Lego Movie", "Despicable Me"),
        setOf("Comedy", "Thriller") to listOf("The Nice Guys", "The Wolf of Wall Street", "Burn After Reading"),

        setOf("Drama", "Romance") to listOf("The Notebook", "La La Land", "Titanic"),
        setOf("Drama", "Sci-Fi") to listOf("Her", "Children of Men", "The Prestige"),
        setOf("Drama", "Horror") to listOf("Black Swan", "The Babadook", "The Others"),
        setOf("Drama", "Mystery") to listOf("Prisoners", "Mystic River", "The Girl with the Dragon Tattoo"),
        setOf("Drama", "Fantasy") to listOf("The Shape of Water", "Pan's Labyrinth", "Big Fish"),
        setOf("Drama", "Animation") to listOf("Soul", "Up", "Inside Out"),
        setOf("Drama", "Thriller") to listOf("Gone Girl", "Nightcrawler", "Whiplash"),

        setOf("Romance", "Sci-Fi") to listOf("The Time Traveler’s Wife", "About Time", "Eternal Sunshine of the Spotless Mind"),
        setOf("Romance", "Horror") to listOf("Warm Bodies", "Spring", "Only Lovers Left Alive"),
        setOf("Romance", "Mystery") to listOf("The Lake House", "The Age of Adaline", "Passengers"),
        setOf("Romance", "Fantasy") to listOf("The Shape of Water", "Twilight", "Stardust"),
        setOf("Romance", "Animation") to listOf("WALL·E", "Beauty and the Beast", "Your Name"),
        setOf("Romance", "Thriller") to listOf("Original Sin", "The Bodyguard", "Red Sparrow"),

        setOf("Sci-Fi", "Horror") to listOf("Alien", "Annihilation", "The Fly"),
        setOf("Sci-Fi", "Mystery") to listOf("Arrival", "Predestination", "Coherence"),
        setOf("Sci-Fi", "Fantasy") to listOf("Avatar", "Dune", "Everything Everywhere All at Once"),
        setOf("Sci-Fi", "Animation") to listOf("WALL·E", "Treasure Planet", "Meet the Robinsons"),
        setOf("Sci-Fi", "Thriller") to listOf("Source Code", "Upgrade", "I, Robot"),

        setOf("Horror", "Mystery") to listOf("Get Out", "The Sixth Sense", "A Quiet Place"),
        setOf("Horror", "Fantasy") to listOf("The Witch", "Coraline", "Crimson Peak"),
        setOf("Horror", "Animation") to listOf("Monster House", "Hotel Transylvania", "Frankenweenie"),
        setOf("Horror", "Thriller") to listOf("The Conjuring", "Us", "Don't Breathe"),

        setOf("Mystery", "Fantasy") to listOf("The Others", "The Imaginarium of Doctor Parnassus", "The Lovely Bones"),
        setOf("Mystery", "Animation") to listOf("Coco", "Kubo and the Two Strings", "Coraline"),
        setOf("Mystery", "Thriller") to listOf("Shutter Island", "Zodiac", "The Girl on the Train"),

        setOf("Fantasy", "Animation") to listOf("How to Train Your Dragon", "Spirited Away", "Frozen"),
        setOf("Fantasy", "Thriller") to listOf("Doctor Strange in the Multiverse of Madness", "The Dark Tower", "The Invisible Man"),

        setOf("Animation", "Thriller") to listOf("The Incredibles", "Big Hero 6", "Rango")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtResult = findViewById(R.id.txtMovieResult)

        val genreButtons = mapOf(
            "Action" to findViewById<Button>(R.id.btnAction),
            "Comedy" to findViewById(R.id.btnComedy),
            "Drama" to findViewById(R.id.btnDrama),
            "Romance" to findViewById(R.id.btnRomance),
            "Sci-Fi" to findViewById(R.id.btnSciFi),
            "Horror" to findViewById(R.id.btnHorror),
            "Mystery" to findViewById(R.id.btnMystery),
            "Fantasy" to findViewById(R.id.btnFantasy),
            "Animation" to findViewById(R.id.btnAnimation),
            "Thriller" to findViewById(R.id.btnThriller)
        )

        for ((genre, button) in genreButtons) {
            button.setOnClickListener {
                if (selectedGenres.contains(genre)) {
                    selectedGenres.remove(genre)
                    button.setTypeface(null, Typeface.NORMAL)
                    button.alpha = 1.0f
                } else if (selectedGenres.size < 2) {
                    selectedGenres.add(genre)
                    button.setTypeface(null, Typeface.BOLD_ITALIC)
                    button.alpha = 0.6f
                } else {
                    Toast.makeText(this, "Only 2 genres allowed", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val btnSuggest = findViewById<Button>(R.id.btnSuggest)
        btnSuggest.setOnClickListener {
            if (selectedGenres.size != 2) {
                Toast.makeText(this, "Please select 2 genres", Toast.LENGTH_SHORT).show()
            } else {
                val matchedList = movieSuggestions[selectedGenres] ?: listOf(
                    "No direct match, try different genres!",
                    "The Grand Budapest Hotel",
                    "Everything Everywhere All at Once"
                )
                val suggestion = matchedList.random()
                txtResult.text = "🎥 You should watch: $suggestion"
            }
        }

        val btnInfo = findViewById<Button>(R.id.btnInfo)
        btnInfo.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("How to Use")
                .setMessage(
                    "1. Select exactly 2 genres from the list.\n" +
                            "2. Tap 'Suggest Movie' to receive a film recommendation.\n\n" +
                            "🎬 Have fun exploring great films!"
                )
                .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                .show()
        }
    }
}
